"use strict";

const { sinalSlide } = require("./_shared");

module.exports = sinalSlide({
  slug: "carrossel_sinais_2_horario_1080x1350",
  contador: "2/5",
  icon: "lead",
  titulo: "Sinal 1: o cliente\nmanda mensagem\nàs 23h",
  corpo: "E só vê a resposta do seu time às 9h do dia seguinte. Até lá, ele já mandou a mesma pergunta pra três concorrentes.",
  rotuloDado: "23:47 · sem resposta",
});
