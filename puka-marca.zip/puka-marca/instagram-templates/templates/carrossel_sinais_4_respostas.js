"use strict";

const { sinalSlide } = require("./_shared");

module.exports = sinalSlide({
  slug: "carrossel_sinais_4_respostas_1080x1350",
  contador: "4/5",
  icon: "equipe",
  titulo: "Sinal 3: cada\natendente responde\numa coisa diferente",
  corpo: "Um promete desconto, outro não sabe do plano, um terceiro repete a pergunta que ele já respondeu. O lead desiste antes de decidir.",
  rotuloDado: "3 respostas · 1 pergunta",
});
