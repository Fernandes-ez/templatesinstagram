"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");
const { fonts, FEED, eyebrow } = require("./_shared");

// Linha de lista marcada por um tick de haste (em vez de bullet redondo) —
// regra 02 do sistema gráfico, nada de marcador nativo do Instagram.
function checklistRow({ doc, x, y, titulo, apoio }) {
  return [
    L.hasteLayer({ name: `linha_${y}_haste`, doc, x, y: y + 6, h: 40, color: brand.color.ribaltaFunda, w: 8 }),
    L.textLayer({ name: `linha_${y}_titulo`, doc, x: x + 28, y, text: titulo, font: fonts.textoBold, size: 36, color: brand.color.coxia }),
    L.textLayer({ name: `linha_${y}_apoio`, doc, x: x + 28, y: y + 44, text: apoio, font: fonts.texto, size: 26, color: brand.color.bastidor, maxWidth: 760 }),
  ];
}

module.exports = {
  slug: "feed_checklist_1080x1350",
  async build() {
    const doc = { width: FEED.width, height: FEED.height, dark: false };
    const m = FEED.margin;
    const rows = [
      { titulo: "IA responde primeiro", apoio: "Toda conversa começa atendida, 24h por dia." },
      { titulo: "Leads distribuídos sozinhos", apoio: "Sem fila manual, sem favoritismo entre atendentes." },
      { titulo: "Time só entra quando importa", apoio: "Foco em quem já tá quase fechando." },
      { titulo: "Tudo registrado no CRM", apoio: "Pipeline, tarefas e histórico num só lugar." },
    ];
    const rowStart = m + 350;
    const rowGap = 148;

    const fundo = group("Fundo", [
      L.rectLayer({ name: "Roteiro", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.roteiro }),
    ]);

    // Divisória reta entre o título e a lista — clara dos dois lados
    // (lacuna generosa acima e abaixo), não atrás do texto.
    const grafismos = group("Grafismos", [
      L.rectLayer({ name: "Divisoria", doc, x: m, y: 340, w: 200, h: 6, color: brand.color.ribaltaFunda }),
    ]);

    const linhas = rows.flatMap((row, i) => checklistRow({ doc, x: m + 30, y: rowStart + i * rowGap, titulo: row.titulo, apoio: row.apoio }));

    const texto = group("Texto", [
      ...eyebrow({ L, doc, x: m, y: m, label: "O que muda", color: brand.color.ribaltaFunda }),
      L.textLayer({ name: "Titulo", doc, x: m, y: m + 130, text: "No seu WhatsApp", font: fonts.display, size: 58, color: brand.color.coxia, maxWidth: 760 }),
      ...linhas,
      ...L.ctaLayers({ name: "CTA", doc, x: m, y: doc.height - m - 92, w: 320, h: 92, label: "Testa grátis", fonts }),
    ]);

    const logo = group("Logo", [
      await L.logoLayer({ name: "Puka_simbolo", doc, x: doc.width - m - 56, y: doc.height - m - 64, width: 56, file: brand.logo.simboloCor }),
    ]);

    const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

    return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, logo, guias] });
  },
};
