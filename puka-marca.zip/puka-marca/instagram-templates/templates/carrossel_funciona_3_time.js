"use strict";

const brand = require("../brand.config");
const { funcionaStep } = require("./_shared");

module.exports = funcionaStep({
  slug: "carrossel_funciona_3_time_1080x1350",
  contador: "3/5",
  bg: brand.color.rotunda,
  dark: false,
  accent: brand.color.ribaltaFunda,
  textoCor: brand.color.coxia,
  bastidorCor: brand.color.bastidor,
  icon: "equipe",
  titulo: "Passo 2: seu time\nentra na deixa",
  corpo: "Quando a conversa esquenta, um consultor assume — com o histórico inteiro na tela, sem o lead repetir nada.",
  rotulo: "Handoff com histórico",
});
