"use strict";

const { sinalSlide } = require("./_shared");

module.exports = sinalSlide({
  slug: "carrossel_sinais_3_preco_1080x1350",
  contador: "3/5",
  icon: "conversa",
  titulo: "Sinal 2: ele\npergunta o preço\ne some",
  corpo: "Ninguém retomou a conversa no momento certo. Pra ele, silêncio depois do valor é resposta — só que negativa.",
  rotuloDado: "48h · sem retorno",
});
