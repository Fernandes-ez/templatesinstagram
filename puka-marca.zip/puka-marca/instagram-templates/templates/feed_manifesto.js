"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");
const { fonts, FEED } = require("./_shared");

// Peça só de tipografia — sem ícone, sem CTA, sem bloco. É a única peça do
// catálogo com Ribalta como fundo inteiro (de propósito: usada uma vez só,
// mantém a proporção 60/25/10/5 — seção 06 do manual — no conjunto como um
// todo mesmo com essa exceção pontual).
module.exports = {
  slug: "feed_manifesto_1080x1350",
  async build() {
    const doc = { width: FEED.width, height: FEED.height, dark: true };
    const m = FEED.margin;

    const fundo = group("Fundo", [
      L.rectLayer({ name: "Ribalta_funda", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.ribaltaFunda }),
    ]);

    const grafismos = group("Grafismos", [
      await L.deixaLayer({ name: "Deixa", doc, x: m - 10, y: doc.height - 170, height: 140, color: brand.color.coxia, flipX: true }),
    ]);

    const texto = group("Texto", [
      L.textLayer({ name: "Eyebrow", doc, x: m, y: m, text: "Puka CRM", font: fonts.monoMedium, size: 22, color: brand.color.roteiro, tracking: 2, uppercase: true }),
      L.textLayer({
        name: "Manifesto",
        doc,
        x: m,
        y: doc.height * 0.3,
        text: "Ninguém\nfica esperando\nresposta.",
        font: fonts.display,
        size: 96,
        color: brand.color.roteiro,
        maxWidth: 900,
        lineHeight: 102,
      }),
    ]);

    const logo = group("Logo", [
      await L.logoLayer({ name: "Puka_simbolo_negativo", doc, x: doc.width - m - 56, y: doc.height - m - 64, width: 56, file: brand.logo.simboloNegativo }),
    ]);

    const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

    return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, logo, guias] });
  },
};
