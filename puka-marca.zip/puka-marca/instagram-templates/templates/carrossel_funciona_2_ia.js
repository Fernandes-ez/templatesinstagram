"use strict";

const brand = require("../brand.config");
const { funcionaStep } = require("./_shared");

module.exports = funcionaStep({
  slug: "carrossel_funciona_2_ia_1080x1350",
  contador: "2/5",
  bg: brand.color.roteiro,
  dark: false,
  accent: brand.color.ponto,
  textoCor: brand.color.coxia,
  bastidorCor: brand.color.bastidor,
  icon: "conversa",
  titulo: "Passo 1: a IA\nresponde na hora",
  corpo: "Qualquer hora, qualquer dia da semana. O lead nunca fica olhando pro \"visto\" sem resposta.",
  rotulo: "24 horas por dia",
});
