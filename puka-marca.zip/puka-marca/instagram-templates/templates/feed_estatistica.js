"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");
const { fonts, FEED, eyebrow } = require("./_shared");

module.exports = {
  slug: "feed_estatistica_1080x1350",
  async build() {
    const doc = { width: FEED.width, height: FEED.height, dark: true };
    const m = FEED.margin;

    const fundo = group("Fundo", [
      L.rectLayer({ name: "Coxia", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.coxia }),
    ]);

    // deixa pequena no canto, única marca gráfica — o número é o
    // protagonista absoluto da peça, sem disputar espaço.
    const grafismos = group("Grafismos", [
      await L.deixaLayer({ name: "Deixa", doc, x: doc.width - 160, y: doc.height - 240, height: 110, color: brand.color.ribaltaAcesa }),
    ]);

    const texto = group("Texto", [
      ...eyebrow({ L, doc, x: m, y: m, label: "Dado do setor", color: brand.color.pontoClaro }),
      L.textLayer({
        name: "Numero",
        doc,
        x: m - 8,
        y: doc.height * 0.22,
        text: "70%",
        font: fonts.display,
        size: 340,
        color: brand.color.roteiro,
      }),
      L.textLayer({
        name: "Apoio",
        doc,
        x: m,
        y: doc.height * 0.62,
        text: "dos leads que esperam mais de 1 hora de resposta no WhatsApp já procuraram outro lugar.",
        font: fonts.texto,
        size: 36,
        color: brand.color.pontoClaro,
        maxWidth: 760,
        lineHeight: 48,
      }),
      L.textLayer({
        name: "Fonte",
        doc,
        x: m,
        y: doc.height - m - 50,
        text: "fonte: pesquisa do setor — troque pela sua",
        font: fonts.mono,
        size: 20,
        color: brand.color.bastidor,
      }),
    ]);

    // canto superior direito — livre (eyebrow fica à esquerda), evita
    // disputar espaço com a legenda de fonte no rodapé.
    const logo = group("Logo", [
      await L.logoLayer({ name: "Puka_simbolo_negativo", doc, x: doc.width - m - 56, y: m, width: 56, file: brand.logo.simboloNegativo }),
    ]);

    const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

    return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, logo, guias] });
  },
};
