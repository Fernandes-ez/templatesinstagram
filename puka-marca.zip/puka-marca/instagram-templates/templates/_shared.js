"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");

const fonts = {
  display: brand.font.display.extraBold,
  displayBold: brand.font.display.bold,
  texto: brand.font.texto.regular,
  textoBold: brand.font.texto.bold,
  mono: brand.font.mono.regular,
  monoMedium: brand.font.mono.medium,
};

const FEED = { width: brand.canvas.feed.width, height: brand.canvas.feed.height, margin: brand.canvas.feed.margin };
const STORY = { width: brand.canvas.story.width, height: brand.canvas.story.height, safeZone: brand.canvas.story.safeZone };

/** Eyebrow padrão: haste fininha + rótulo mono tracked em caixa alta. */
function eyebrow({ L, doc, x, y, label, color }) {
  return [
    { ...L.hasteLayer({ name: "eyebrow_haste", doc, x, y: y + 2, h: 22, color, w: 5 }) },
    L.textLayer({ name: "eyebrow_texto", doc, x: x + 16, y, text: label, font: fonts.monoMedium, size: 22, color, tracking: 2, uppercase: true }),
  ];
}

// -----------------------------------------------------------------------
// Moldura comum do carrossel "3 sinais" (slides de conteúdo 2-4): papel,
// haste Ponto no topo, ícone + número do contador, título/corpo/rótulo de
// dado em Ribalta Funda. Usada pelos 3 slides de sinal pra manter o mesmo
// ritmo visual ao deslizar — só muda ícone e texto.
// -----------------------------------------------------------------------
function sinalSlide({ slug, contador, icon, titulo, corpo, rotuloDado }) {
  return {
    slug,
    async build() {
      const doc = { width: FEED.width, height: FEED.height, dark: false };
      const m = FEED.margin;

      const fundo = group("Fundo", [
        L.rectLayer({ name: "Papel", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.papel }),
      ]);

      const grafismos = group("Grafismos", [
        L.hasteLayer({ name: "Haste_topo", doc, x: m, y: m, h: 90, color: brand.color.ponto }),
      ]);

      const icone = await L.iconLayer({ name: "Icone", doc, x: m + 30, y: m + 130, size: 56, icon, color: brand.color.ribaltaFunda });

      const texto = group("Texto", [
        L.textLayer({ name: "Contador", doc, x: doc.width - m - 60, y: m, text: contador, font: fonts.mono, size: 24, color: brand.color.bastidor }),
        icone,
        L.textLayer({ name: "Titulo", doc, x: m, y: m + 240, text: titulo, font: fonts.display, size: 66, color: brand.color.coxia, maxWidth: 820, lineHeight: 72 }),
        L.textLayer({ name: "Corpo", doc, x: m, y: m + 500, text: corpo, font: fonts.texto, size: 34, color: brand.color.bastidor, maxWidth: 780, lineHeight: 46 }),
        L.textLayer({ name: "Rotulo_dado", doc, x: m, y: doc.height - m - 60, text: rotuloDado, font: fonts.mono, size: 24, color: brand.color.ribaltaFunda }),
      ]);

      const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

      return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, group("Logo", []), guias] });
    },
  };
}

// -----------------------------------------------------------------------
// Moldura comum do carrossel "como funciona" (passos 2-4): fundo muda de
// cor a cada passo (claro → neutro → escuro — a peça fica mais "noite"
// conforme a história avança até a final escura), ícone grande + haste
// lateral na cor de destaque do passo, título/corpo/rótulo.
// -----------------------------------------------------------------------
function funcionaStep({ slug, contador, bg, dark, accent, textoCor, bastidorCor, icon, titulo, corpo, rotulo }) {
  return {
    slug,
    async build() {
      const doc = { width: FEED.width, height: FEED.height, dark };
      const m = FEED.margin;

      const fundo = group("Fundo", [
        L.rectLayer({ name: "Fundo_passo", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: bg }),
      ]);

      const grafismos = group("Grafismos", [
        L.hasteLayer({ name: "Haste_lateral", doc, x: 0, y: 0, h: doc.height, color: accent, w: 14 }),
      ]);

      const icone = await L.iconLayer({ name: "Icone", doc, x: m + 20, y: m + 60, size: 84, icon, color: accent });

      const texto = group("Texto", [
        L.textLayer({ name: "Contador", doc, x: doc.width - m - 60, y: m, text: contador, font: fonts.mono, size: 24, color: bastidorCor }),
        icone,
        L.textLayer({ name: "Titulo", doc, x: m + 20, y: m + 230, text: titulo, font: fonts.display, size: 70, color: textoCor, maxWidth: 820, lineHeight: 76 }),
        L.textLayer({ name: "Corpo", doc, x: m + 20, y: m + 500, text: corpo, font: fonts.texto, size: 34, color: bastidorCor, maxWidth: 760, lineHeight: 46 }),
        L.textLayer({ name: "Rotulo", doc, x: m + 20, y: doc.height - m - 60, text: rotulo, font: fonts.mono, size: 24, color: accent, tracking: 1, uppercase: true }),
      ]);

      const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

      return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, group("Logo", []), guias] });
    },
  };
}

module.exports = { fonts, FEED, STORY, eyebrow, sinalSlide, funcionaStep };
