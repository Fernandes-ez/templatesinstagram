"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");
const { fonts, STORY, eyebrow } = require("./_shared");

// Story pra pergunta com figurinha de enquete nativa do Instagram — reserva
// um espaço marcado (não é uma figurinha de verdade, isso só existe dentro
// do app) pra quem for montar o story saber onde colar ela em cima.
module.exports = {
  slug: "story_enquete_1080x1920",
  async build() {
    const doc = { width: STORY.width, height: STORY.height, dark: true };
    const safe = STORY.safeZone;
    const m = 80;

    const fundo = group("Fundo", [
      L.rectLayer({ name: "Coxia", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.coxia }),
    ]);

    const grafismos = group("Grafismos", [
      await L.deixaLayer({ name: "Deixa", doc, x: m, y: safe + 80, height: 130, color: brand.color.ribaltaAcesa }),
      // área reservada da figurinha de enquete: bloco translúcido só de
      // referência (a figurinha de verdade vai por cima, dentro do app do
      // Instagram — isso aqui é só pra marcar onde colar).
      L.rectLayer({ name: "Area_figurinha", doc, x: m, y: safe + 820, w: doc.width - m * 2, h: 180, color: brand.color.bastidor, alpha: 0.35 }),
    ]);

    const texto = group("Texto", [
      ...eyebrow({ L, doc, x: m, y: safe + 280, label: "Pergunta", color: brand.color.ribaltaAcesa }),
      L.textLayer({
        name: "Pergunta",
        doc,
        x: m,
        y: safe + 360,
        text: "Seu time já perdeu\nlead por demorar\npra responder?",
        font: fonts.display,
        size: 64,
        color: brand.color.roteiro,
        maxWidth: 900,
        lineHeight: 72,
      }),
      L.textLayer({
        name: "Rotulo_figurinha",
        doc,
        x: m + 24,
        y: safe + 886,
        text: "cole a figurinha de enquete aqui",
        font: fonts.mono,
        size: 24,
        color: brand.color.bastidor,
        maxWidth: doc.width - m * 2 - 48,
      }),
    ]);

    const logo = group("Logo", [
      await L.logoLayer({ name: "Puka_simbolo_negativo", doc, x: doc.width / 2 - 40, y: doc.height - safe - 130, width: 80, file: brand.logo.simboloNegativo }),
    ]);

    const guias = group(
      "Guias",
      [L.guidesLayer({ name: "Safe_zone", doc, safeTop: safe, safeBottom: safe })],
      false
    );

    return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, logo, guias] });
  },
};
