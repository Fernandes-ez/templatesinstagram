"use strict";

const brand = require("../brand.config");
const { funcionaStep } = require("./_shared");

module.exports = funcionaStep({
  slug: "carrossel_funciona_4_crm_1080x1350",
  contador: "4/5",
  bg: brand.color.coxia,
  dark: true,
  accent: brand.color.pontoClaro,
  textoCor: brand.color.roteiro,
  bastidorCor: brand.color.pontoClaro,
  icon: "etapas",
  titulo: "Passo 3: o CRM\norganiza sozinho",
  corpo: "Pipeline, tarefas e observações puxados automaticamente da conversa — nada de planilha paralela pra manter.",
  rotulo: "Zero planilha",
});
