"use strict";

const brand = require("../brand.config");
const L = require("../lib/layers");
const { group, buildDoc } = require("../lib/psd");
const { fonts, FEED, eyebrow } = require("./_shared");

module.exports = {
  slug: "carrossel_funciona_1_capa_1080x1350",
  async build() {
    const doc = { width: FEED.width, height: FEED.height, dark: true };
    const m = FEED.margin;

    const fundo = group("Fundo", [
      L.rectLayer({ name: "Coxia", doc, x: 0, y: 0, w: doc.width, h: doc.height, color: brand.color.coxia }),
    ]);

    // deixa gigante sangrando — mesma regra de escala por salto da capa do
    // outro carrossel, mas aqui em Coxia (fundo escuro) pra abrir essa
    // história num tom mais "virada de chave" que o gancho de alerta.
    const grafismos = group("Grafismos", [
      await L.deixaLayer({ name: "Deixa_gigante", doc, x: doc.width - 400, y: doc.height * 0.3, height: doc.height * 0.58, color: brand.color.ribaltaAcesa }),
    ]);

    const texto = group("Texto", [
      L.textLayer({ name: "Contador", doc, x: m, y: m, text: "1/5", font: fonts.mono, size: 24, color: brand.color.bastidor }),
      ...eyebrow({ L, doc, x: m, y: m + 150, label: "Como funciona", color: brand.color.pontoClaro }),
      L.textLayer({
        name: "Titulo_gancho",
        doc,
        x: m,
        y: m + 260,
        text: "Do primeiro\n\"oi\" até a\nvenda fechada.",
        font: fonts.display,
        size: 88,
        color: brand.color.roteiro,
        maxWidth: 640,
        lineHeight: 94,
      }),
      L.textLayer({ name: "Apoio", doc, x: m, y: doc.height - m - 60, text: "desliza →", font: fonts.mono, size: 26, color: brand.color.ribaltaAcesa, tracking: 1 }),
    ]);

    const logo = group("Logo", [
      await L.logoLayer({ name: "Puka_simbolo_negativo", doc, x: doc.width - m - 56, y: doc.height - m - 64, width: 56, file: brand.logo.simboloNegativo }),
    ]);

    const guias = group("Guias", [L.guidesLayer({ name: "Margem_grade", doc, margin: m })], false);

    return buildDoc({ width: doc.width, height: doc.height, groups: [fundo, grafismos, group("Imagem (substituir)", []), texto, logo, guias] });
  },
};
