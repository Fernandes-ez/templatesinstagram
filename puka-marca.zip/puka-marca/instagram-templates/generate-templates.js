"use strict";

const path = require("path");
const { registerAll } = require("./lib/fonts");
const { writeAndPreview } = require("./lib/psd");

registerAll();

const TEMPLATES = [
  require("./templates/feed_anuncio"),
  require("./templates/feed_dica"),
  require("./templates/feed_depoimento"),
  require("./templates/feed_antes_depois"),
  require("./templates/feed_checklist"),
  require("./templates/feed_estatistica"),
  require("./templates/feed_manifesto"),
  require("./templates/story"),
  require("./templates/story_enquete"),
  require("./templates/carrossel_sinais_1_capa"),
  require("./templates/carrossel_sinais_2_horario"),
  require("./templates/carrossel_sinais_3_preco"),
  require("./templates/carrossel_sinais_4_respostas"),
  require("./templates/carrossel_sinais_5_final"),
  require("./templates/carrossel_funciona_1_capa"),
  require("./templates/carrossel_funciona_2_ia"),
  require("./templates/carrossel_funciona_3_time"),
  require("./templates/carrossel_funciona_4_crm"),
  require("./templates/carrossel_funciona_5_final"),
];

async function main() {
  const outDir = path.join(__dirname, "output");
  for (const tpl of TEMPLATES) {
    process.stdout.write(`gerando ${tpl.slug}... `);
    const doc = await tpl.build();
    const result = await writeAndPreview(doc, outDir, tpl.slug);
    console.log(`ok (${(result.bytes / 1024).toFixed(0)} KB)`);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
